package com.example.artemkinrpm

import android.R.bool
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.example.artemkinrpm.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var pass: String
    private lateinit var confPass: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        var pass = ""
        var confPass = ""
        binding.registerBtn.setOnClickListener {
            val errMail = binding.errorMail.isVisible
            val errPass = binding.errorPass.isVisible
            val confPass = binding.errorConfPass.isVisible
            if (errMail || errPass || confPass || binding.confirmPass.text.isEmpty()
                || binding.inputEmail.text.isEmpty() || binding.inputPassword.text.isEmpty()) {
                Toast.makeText(applicationContext, "Input all fields", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(applicationContext, "Success!", Toast.LENGTH_SHORT).show()
        }

        binding.inputLogin.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(
                s: CharSequence, start: Int, before: Int,
                count: Int
            ) {
                if (s.length in 1..7) {
                    binding.errorLogin.isVisible = true
                    binding.errorLogin.text = "must be at least 8 characters long"
                } else {
                    binding.errorLogin.isVisible = false
                    binding.registerBtn.isEnabled = s.length > 7
                }
            }

            override fun beforeTextChanged(
                s: CharSequence, start: Int, count: Int,
                after: Int
            ) {
            }

            override fun afterTextChanged(s: Editable) {}
        })
        binding.inputEmail.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (s.isValidEmail() || s.isEmpty()) {
                    binding.errorMail.isVisible = false
                } else {
                    binding.errorMail.isVisible = true
                    binding.errorMail.text = "invalid email"

                }
            }

            override fun beforeTextChanged(
                s: CharSequence, start: Int, count: Int,
                after: Int
            ) {
            }

            override fun afterTextChanged(s: Editable) {}
        })

        binding.inputPassword.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(
                s: CharSequence, start: Int, before: Int,
                count: Int
            ) {
                pass = s.toString()
                var isNumber = false
                var isLetter = false
                for (char in s) {
                    if (char.isDigit())
                        isNumber = true
                    if (char.isLetter())
                        isLetter = true
                }

                if (s.length in 1..7 || !isNumber || !isLetter || s.isEmpty()) {
                    binding.errorPass.isVisible = true
                    binding.errorPass.text =
                        "must contain at least 1 number and 1 letter\nmin 8 characters"
                } else binding.errorPass.isVisible = false

            }

            override fun beforeTextChanged(
                s: CharSequence, start: Int, count: Int,
                after: Int
            ) {
            }

            override fun afterTextChanged(s: Editable) {
                if (confPass == pass || confPass.isEmpty()) {
                    binding.errorConfPass.isVisible = false
                } else {
                    binding.errorConfPass.isVisible = true
                    binding.errorConfPass.text =
                        "passwords do not match"
                }
            }
        })

        binding.confirmPass.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(
                s: CharSequence, start: Int, before: Int,
                count: Int
            ) {

            }

            override fun beforeTextChanged(
                s: CharSequence, start: Int, count: Int,
                after: Int
            ) {
            }

            override fun afterTextChanged(s: Editable) {
                confPass = s.toString()
                val cPass = s.toString()
                if (cPass == pass || s.isEmpty()) {
                    binding.errorConfPass.isVisible = false
                } else {
                    binding.errorConfPass.isVisible = true
                    binding.errorConfPass.text =
                        "passwords do not match"
                }
            }
        })
    }

    fun CharSequence?.isValidEmail(): Boolean {
        return !isNullOrEmpty() && Patterns.EMAIL_ADDRESS.matcher(this).matches()
    }

}